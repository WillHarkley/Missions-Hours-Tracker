﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmAssignment2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.grpMissions = New System.Windows.Forms.GroupBox()
        Me.radConstruction = New System.Windows.Forms.RadioButton()
        Me.radItems = New System.Windows.Forms.RadioButton()
        Me.radCooking = New System.Windows.Forms.RadioButton()
        Me.lblhours = New System.Windows.Forms.Label()
        Me.lblpeople = New System.Windows.Forms.Label()
        Me.lblTotalhrs = New System.Windows.Forms.Label()
        Me.lblRemaining = New System.Windows.Forms.Label()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.txtHmh = New System.Windows.Forms.TextBox()
        Me.txtPpl = New System.Windows.Forms.TextBox()
        Me.lblTotalresults = New System.Windows.Forms.Label()
        Me.lblRemainingresults = New System.Windows.Forms.Label()
        Me.grpMissions.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpMissions
        '
        Me.grpMissions.BackColor = System.Drawing.SystemColors.WindowFrame
        Me.grpMissions.Controls.Add(Me.radConstruction)
        Me.grpMissions.Controls.Add(Me.radItems)
        Me.grpMissions.Controls.Add(Me.radCooking)
        Me.grpMissions.Location = New System.Drawing.Point(12, 22)
        Me.grpMissions.Name = "grpMissions"
        Me.grpMissions.Size = New System.Drawing.Size(226, 121)
        Me.grpMissions.TabIndex = 0
        Me.grpMissions.TabStop = False
        Me.grpMissions.Text = "Missions"
        '
        'radConstruction
        '
        Me.radConstruction.AutoSize = True
        Me.radConstruction.Location = New System.Drawing.Point(19, 89)
        Me.radConstruction.Name = "radConstruction"
        Me.radConstruction.Size = New System.Drawing.Size(122, 25)
        Me.radConstruction.TabIndex = 2
        Me.radConstruction.TabStop = True
        Me.radConstruction.Text = "Construction"
        Me.radConstruction.UseVisualStyleBackColor = True
        '
        'radItems
        '
        Me.radItems.AutoSize = True
        Me.radItems.Location = New System.Drawing.Point(19, 58)
        Me.radItems.Name = "radItems"
        Me.radItems.Size = New System.Drawing.Size(136, 25)
        Me.radItems.TabIndex = 1
        Me.radItems.TabStop = True
        Me.radItems.Text = "Item Inventory"
        Me.radItems.UseVisualStyleBackColor = True
        '
        'radCooking
        '
        Me.radCooking.AutoSize = True
        Me.radCooking.Location = New System.Drawing.Point(19, 28)
        Me.radCooking.Name = "radCooking"
        Me.radCooking.Size = New System.Drawing.Size(89, 25)
        Me.radCooking.TabIndex = 0
        Me.radCooking.TabStop = True
        Me.radCooking.Text = "Cooking"
        Me.radCooking.UseVisualStyleBackColor = True
        '
        'lblhours
        '
        Me.lblhours.AutoSize = True
        Me.lblhours.Location = New System.Drawing.Point(333, 50)
        Me.lblhours.Name = "lblhours"
        Me.lblhours.Size = New System.Drawing.Size(136, 21)
        Me.lblhours.TabIndex = 1
        Me.lblhours.Text = "How many hours"
        '
        'lblpeople
        '
        Me.lblpeople.AutoSize = True
        Me.lblpeople.Location = New System.Drawing.Point(590, 50)
        Me.lblpeople.Name = "lblpeople"
        Me.lblpeople.Size = New System.Drawing.Size(148, 21)
        Me.lblpeople.TabIndex = 2
        Me.lblpeople.Text = "Number of People"
        '
        'lblTotalhrs
        '
        Me.lblTotalhrs.AccessibleRole = System.Windows.Forms.AccessibleRole.Column
        Me.lblTotalhrs.AutoSize = True
        Me.lblTotalhrs.Location = New System.Drawing.Point(60, 281)
        Me.lblTotalhrs.Name = "lblTotalhrs"
        Me.lblTotalhrs.Size = New System.Drawing.Size(178, 21)
        Me.lblTotalhrs.TabIndex = 3
        Me.lblTotalhrs.Text = "Number of total hours"
        '
        'lblRemaining
        '
        Me.lblRemaining.AutoSize = True
        Me.lblRemaining.Location = New System.Drawing.Point(333, 281)
        Me.lblRemaining.Name = "lblRemaining"
        Me.lblRemaining.Size = New System.Drawing.Size(217, 21)
        Me.lblRemaining.TabIndex = 4
        Me.lblRemaining.Text = "Number of remaining hours"
        '
        'btnCalc
        '
        Me.btnCalc.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnCalc.Location = New System.Drawing.Point(362, 152)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(89, 33)
        Me.btnCalc.TabIndex = 5
        Me.btnCalc.Text = "&Calculate"
        Me.btnCalc.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnClear.Location = New System.Drawing.Point(635, 152)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(79, 33)
        Me.btnClear.TabIndex = 6
        Me.btnClear.Text = "&Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnClose.Location = New System.Drawing.Point(659, 373)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(79, 33)
        Me.btnClose.TabIndex = 7
        Me.btnClose.Text = "&Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'txtHmh
        '
        Me.txtHmh.AcceptsReturn = True
        Me.txtHmh.AcceptsTab = True
        Me.txtHmh.Location = New System.Drawing.Point(351, 80)
        Me.txtHmh.Name = "txtHmh"
        Me.txtHmh.Size = New System.Drawing.Size(100, 29)
        Me.txtHmh.TabIndex = 3
        '
        'txtPpl
        '
        Me.txtPpl.AcceptsReturn = True
        Me.txtPpl.AcceptsTab = True
        Me.txtPpl.Location = New System.Drawing.Point(614, 79)
        Me.txtPpl.Name = "txtPpl"
        Me.txtPpl.Size = New System.Drawing.Size(100, 29)
        Me.txtPpl.TabIndex = 4
        '
        'lblTotalresults
        '
        Me.lblTotalresults.AutoSize = True
        Me.lblTotalresults.BackColor = System.Drawing.Color.Gray
        Me.lblTotalresults.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTotalresults.Location = New System.Drawing.Point(101, 320)
        Me.lblTotalresults.Name = "lblTotalresults"
        Me.lblTotalresults.Padding = New System.Windows.Forms.Padding(50, 25, 25, 50)
        Me.lblTotalresults.Size = New System.Drawing.Size(77, 98)
        Me.lblTotalresults.TabIndex = 10
        '
        'lblRemainingresults
        '
        Me.lblRemainingresults.AutoSize = True
        Me.lblRemainingresults.BackColor = System.Drawing.Color.Gray
        Me.lblRemainingresults.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblRemainingresults.Location = New System.Drawing.Point(392, 320)
        Me.lblRemainingresults.Name = "lblRemainingresults"
        Me.lblRemainingresults.Padding = New System.Windows.Forms.Padding(50, 25, 25, 50)
        Me.lblRemainingresults.Size = New System.Drawing.Size(77, 98)
        Me.lblRemainingresults.TabIndex = 11
        '
        'frmAssignment2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 21.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DarkOliveGreen
        Me.ClientSize = New System.Drawing.Size(809, 441)
        Me.Controls.Add(Me.lblRemainingresults)
        Me.Controls.Add(Me.lblTotalresults)
        Me.Controls.Add(Me.txtPpl)
        Me.Controls.Add(Me.txtHmh)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalc)
        Me.Controls.Add(Me.lblRemaining)
        Me.Controls.Add(Me.lblTotalhrs)
        Me.Controls.Add(Me.lblpeople)
        Me.Controls.Add(Me.lblhours)
        Me.Controls.Add(Me.grpMissions)
        Me.Font = New System.Drawing.Font("Malgun Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "frmAssignment2"
        Me.Text = "Assignment 2"
        Me.grpMissions.ResumeLayout(False)
        Me.grpMissions.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents grpMissions As GroupBox
    Friend WithEvents radConstruction As RadioButton
    Friend WithEvents radItems As RadioButton
    Friend WithEvents radCooking As RadioButton
    Friend WithEvents lblhours As Label
    Friend WithEvents lblpeople As Label
    Friend WithEvents lblTotalhrs As Label
    Friend WithEvents lblRemaining As Label
    Friend WithEvents btnCalc As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnClose As Button
    Friend WithEvents txtHmh As TextBox
    Friend WithEvents txtPpl As TextBox
    Friend WithEvents lblTotalresults As Label
    Friend WithEvents lblRemainingresults As Label
End Class
